import React from "react";

export default () => {
  <button
    style={{
      border: "none",
      backgroundColor: "black",
      color: "white",
      padding: "10px",
      fontWeight: "600",
      fontSize: "13px",
    }}
  >
    New note
  </button>;
};
